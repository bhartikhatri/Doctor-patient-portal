package bharti;

import java.awt.Button;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class patients_feedback {

	JFrame frame;
	private JTextField Doctor_name;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					patients_feedback window = new patients_feedback();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public patients_feedback() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 457, 331);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Feedback for doctor");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(138, 33, 188, 32);
		frame.getContentPane().add(lblNewLabel);
		
		Doctor_name = new JTextField();
		Doctor_name.setToolTipText("");
		Doctor_name.setText("Dr.");
		Doctor_name.setFont(new Font("Tahoma", Font.PLAIN, 11));
		Doctor_name.setBounds(148, 76, 190, 20);
		frame.getContentPane().add(Doctor_name);
		Doctor_name.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("NAME :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(53, 76, 70, 17);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("for Doctor :");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(53, 120, 82, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		TextArea feedbak = new TextArea();
		feedbak.setBounds(143, 120, 254, 122);
		frame.getContentPane().add(feedbak);
		
		Button button = new Button("< Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				patient_menu window = new patient_menu();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		button.setBounds(10, 10, 70, 22);
		frame.getContentPane().add(button);
		
		Button button_1 = new Button("Logout");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login window = new Login();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		button_1.setBounds(354, 10, 70, 22);
		frame.getContentPane().add(button_1);
		
		Button done = new Button("Done");
		done.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = Doctor_name.getText();
				String Feedback =feedbak.getText();
				if (name.equals("Dr.Mahesh")||name.equals("Dr.mahesh")||name.equals("Dr.Abdul aziz")||name.equals("Dr.abdul aziz")||name.equals("Dr.Bhageshwari")||name.equals("Dr.bhageshwari")) {
					
				try (BufferedWriter writer = new BufferedWriter(new FileWriter(name+".txt", true))) {
					writer.write("Feedback : "+Feedback);
					writer.newLine();
					
					patient_menu window = new patient_menu();
					window.frame.setVisible(true);
					frame.setVisible(false);
		        } catch (IOException ex) {
		            ex.printStackTrace(); // Handle the exception appropriately
		            JOptionPane.showMessageDialog(null, "Error writing to file", "File Error", JOptionPane.ERROR_MESSAGE);
		        
				patient_menu window = new patient_menu();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
				}else {
					JOptionPane.showMessageDialog(null, "Entered doctor name is invalid", "Error", JOptionPane.ERROR_MESSAGE);
			        
					patient_menu window = new patient_menu();
					window.frame.setVisible(true);
					frame.setVisible(false);
				}
				
			}
		});
		done.setFont(new Font("Dialog", Font.BOLD, 12));
		done.setBounds(327, 260, 70, 22);
		frame.getContentPane().add(done);
	}
}
