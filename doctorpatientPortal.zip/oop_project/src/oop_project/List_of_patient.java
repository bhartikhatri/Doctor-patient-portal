package bharti;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Button;
import java.awt.List;
import java.awt.TextArea;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class List_of_patient {

	JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					List_of_patient window = new List_of_patient();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public List_of_patient() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel ListOfPatient = new JLabel("List of Patient's");
		ListOfPatient.setFont(new Font("Tahoma", Font.BOLD, 26));
		ListOfPatient.setBounds(104, 30, 208, 38);
		frame.getContentPane().add(ListOfPatient);
		
		Button button = new Button("< Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Doctor_menu window = new Doctor_menu();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		button.setBounds(10, 10, 70, 22);
		frame.getContentPane().add(button);
		
		Button button_2 = new Button("log out");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login window = new Login();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		button_2.setBounds(340, 10, 70, 22);
		frame.getContentPane().add(button_2);
		
		TextArea textArea = new TextArea();
		textArea.setBounds(57, 109, 311, 142);
		frame.getContentPane().add(textArea);
		
		Button button_1 = new Button("Show");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try (BufferedReader reader = new BufferedReader(new FileReader("List_of_patient.txt"))) {
		            StringBuilder content = new StringBuilder();
		            String line;

		            // Read lines from the file and append to the content StringBuilder
		            while ((line = reader.readLine()) != null) {
		                content.append(line).append("\n");
		            }

		            // Set the content to the text area
		            textArea.setText(content.toString());
		        } catch (IOException ex) {
		            // Handle file not found or other IO exceptions
		            ex.printStackTrace();
		            JOptionPane.showMessageDialog(null, "File not found or error reading file", "Error", JOptionPane.ERROR_MESSAGE);
		        }
			}
		});
		button_1.setFont(new Font("Dialog", Font.BOLD, 13));
		button_1.setBounds(164, 74, 70, 22);
		frame.getContentPane().add(button_1);
	}
}
