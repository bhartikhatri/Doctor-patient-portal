package bharti;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Button;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class Take_Appointment {

	JFrame frame;
	private JTextField name;
	private JTextField day;
	private JTextField dname;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Take_Appointment window = new Take_Appointment();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Take_Appointment() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 495, 314);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		Button button = new Button("< Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				patient_menu window = new patient_menu();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		button.setBounds(10, 20, 70, 22);
		frame.getContentPane().add(button);
		
		JLabel lblTakeAppointment = new JLabel("Take Appointment");
		lblTakeAppointment.setFont(new Font("Tahoma", Font.BOLD, 26));
		lblTakeAppointment.setBounds(108, 50, 248, 49);
		frame.getContentPane().add(lblTakeAppointment);
		
		Button button_2 = new Button("Log out");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login window = new Login();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		button_2.setBounds(387, 20, 70, 22);
		frame.getContentPane().add(button_2);
		
		name = new JTextField();
		name.setBounds(154, 118, 212, 20);
		frame.getContentPane().add(name);
		name.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Your Name : ");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(64, 124, 94, 14);
		frame.getContentPane().add(lblNewLabel);
		
		day = new JTextField();
		day.setBounds(154, 149, 212, 20);
		frame.getContentPane().add(day);
		day.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Enter Day : ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(64, 155, 79, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		Button button_2_1 = new Button("DONE");
		button_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String NAME=name.getText();
				String Day=day.getText();
				String docname=dname.getText();
				if (docname.equals("Mahesh")||docname.equals("mahesh")||docname.equals("Abdul aziz")||docname.equals("abdul aziz")||docname.equals("Bhageshwari")||docname.equals("bhageshwari")) {
					try (BufferedWriter writer = new BufferedWriter(new FileWriter(docname+".txt", true))) {
						writer.write("NAME  | DAYS ");
						writer.newLine();
						writer.write(NAME+"  "+Day);
						writer.newLine();
						
						patient_menu window = new patient_menu();
						window.frame.setVisible(true);
						frame.setVisible(false);
			        } catch (IOException ex) {
			            ex.printStackTrace(); // Handle the exception appropriately
			            JOptionPane.showMessageDialog(null, "Error writing to file", "File Error", JOptionPane.ERROR_MESSAGE);
			        
					patient_menu window = new patient_menu();
					window.frame.setVisible(true);
					frame.setVisible(false);
				}
				}else {
					JOptionPane.showMessageDialog(null, "Thie doctor is not available here", "Sorry", JOptionPane.ERROR_MESSAGE);
			        
				}
				
			}
		});
		button_2_1.setFont(new Font("Dialog", Font.BOLD, 15));
		button_2_1.setBounds(367, 243, 70, 22);
		frame.getContentPane().add(button_2_1);
		
		dname = new JTextField();
		dname.setColumns(10);
		dname.setBounds(154, 180, 212, 20);
		frame.getContentPane().add(dname);
		
		JLabel lblDoctorName = new JLabel("Doctor Name : ");
		lblDoctorName.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblDoctorName.setBounds(64, 186, 94, 14);
		frame.getContentPane().add(lblDoctorName);
		
		JLabel lblNewLabel_2 = new JLabel("Available Doctors : ");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_2.setBounds(154, 211, 172, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Mahesh, Abdul aziz, Bhageshwari");
		lblNewLabel_2_1.setBounds(153, 229, 203, 14);
		frame.getContentPane().add(lblNewLabel_2_1);
	}
}
