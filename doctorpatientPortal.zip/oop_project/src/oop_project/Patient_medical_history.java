package bharti;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Button;
import java.awt.List;
import java.awt.TextArea;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Patient_medical_history {

	JFrame frame;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Patient_medical_history window = new Patient_medical_history();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Patient_medical_history() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 477, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Patient history");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 26));
		lblNewLabel.setBounds(123, 25, 228, 49);
		frame.getContentPane().add(lblNewLabel);
		
		Button button = new Button("< Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Doctor_menu window = new Doctor_menu();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		button.setBounds(10, 10, 70, 22);
		frame.getContentPane().add(button);
		
		Button button_1 = new Button("Log out");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login window = new Login();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		button_1.setBounds(337, 192, 101, 22);
		frame.getContentPane().add(button_1);
		
		TextArea textArea = new TextArea();
		textArea.setBounds(10, 95, 321, 138);
		frame.getContentPane().add(textArea);
		
		Button button_2 = new Button("Show about");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enteredData = textField.getText().trim();
				try (BufferedReader reader = new BufferedReader(new FileReader("patient_"+enteredData+".txt"))) {
		            StringBuilder content = new StringBuilder();
		            String line;

		            // Read lines from the file and append to the content StringBuilder
		            while ((line = reader.readLine()) != null) {
		                content.append(line).append("\n");
		                
		            }// Set the content to the text area
		            textArea.setText(content.toString());
		            

				} catch (IOException ex) {
		            // Handle file not found or other IO exceptions
		            ex.printStackTrace();
		            JOptionPane.showMessageDialog(null, "File not found or error reading file", "Error", JOptionPane.ERROR_MESSAGE);
		        }
			}
		});
		button_2.setBounds(337, 113, 101, 22);
		frame.getContentPane().add(button_2);
		
		textField = new JTextField();
		textField.setBounds(133, 69, 198, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("NAME : ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(72, 67, 56, 22);
		frame.getContentPane().add(lblNewLabel_1);
		
		Button button_2_1 = new Button("Show medicians");
		button_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String enteredData = textField.getText().trim();
				try (BufferedReader reader = new BufferedReader(new FileReader(enteredData+".txt"))) {
		            StringBuilder content = new StringBuilder();
		            String line;

		            // Read lines from the file and append to the content StringBuilder
		            while ((line = reader.readLine()) != null) {
		                content.append(line).append("\n");
		                
		            }// Set the content to the text area
		            textArea.setText(content.toString());
		            

				} catch (IOException ex) {
		            // Handle file not found or other IO exceptions
		            ex.printStackTrace();
		            JOptionPane.showMessageDialog(null, "File not found or error reading file", "Error", JOptionPane.ERROR_MESSAGE);
		        }

				
			}
		});
		button_2_1.setBounds(337, 151, 101, 22);
		frame.getContentPane().add(button_2_1);
	}
}
