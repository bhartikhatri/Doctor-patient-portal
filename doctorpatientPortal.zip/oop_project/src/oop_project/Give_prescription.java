package bharti;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Button;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.TextArea;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;

public class Give_prescription {

	
	JFrame frame;
	private JTextField textField;
	private JTextField medician1;
	private JTextField Quantity1;
	private JTextField medician2;
	private JTextField Quantity2;
	private JTextField medician3;
	private JTextField Quantity3;
	private JTextField medician4;
	private JTextField Quantity4;
	private JTextField medician5;
	private JTextField Quantity5;
	private JTextField Day1;
	private JTextField time1;
	private JTextField Day2;
	private JTextField time2;
	private JTextField Day4;
	private JTextField Day3;
	private JTextField time3;
	private JTextField time4;
	private JTextField Day5;
	private JTextField time5;
	private TextArea recomme;
	private Button logout;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Give_prescription window = new Give_prescription();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Give_prescription() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 495, 567);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		Button button = new Button("< Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Doctor_menu window = new Doctor_menu();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		button.setBounds(10, 10, 70, 22);
		frame.getContentPane().add(button);
		TextArea checkup = new TextArea();
		checkup.setFont(new Font("Dialog", Font.PLAIN, 12));
		checkup.setBounds(31, 397, 411, 96);
		frame.getContentPane().add(checkup);
		
		Button button_1 = new Button("Done");
		button_1.setFont(new Font("Dialog", Font.BOLD, 14));
		button_1.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				String patient_name = textField.getText();
				String Medician1=medician1.getText();
				String day1=Day1.getText();
				String Time1=time1.getText();
				String quantity1=Quantity1.getText();
				String Medician2=medician2.getText();
				String day2=Day2.getText();
				String Time2=time2.getText();
				String quantity2=Quantity2.getText();
				String Medician3=medician3.getText();
				String day3=Day3.getText();
				String Time3=time3.getText();
				String quantity3=Quantity3.getText();
				String Medician4=medician4.getText();
				String day4=Day4.getText();
				String Time4=time4.getText();
				String quantity4=Quantity4.getText();
				String Medician5=medician5.getText();
				String day5=Day5.getText();
				String Time5=time5.getText();
				String quantity5=Quantity5.getText();
				String recomo= recomme.getName();
				String Checkups=checkup.getText();
				if (day1.matches("\\d+")||day2.matches("\\d+")||day3.matches("\\d+")||day4.matches("\\d+")||day5.matches("\\d+")&&(quantity1.matches("\\d+")||quantity2.matches("\\d+")||quantity3.matches("\\d+")||quantity4.matches("\\d+")||quantity5.matches("\\d+"))) {
				try (BufferedWriter writer = new BufferedWriter(new FileWriter(patient_name+".txt", true))) {
					writer.write("MEDICIANS | DAYS | TIME |QUANTITY");
					writer.newLine();
					writer.write(Medician1 +"     "+day1+"     "+Time1+"     "+quantity1);
					writer.newLine();
					writer.write(Medician2 +"     "+day2+"     "+Time2+"      "+quantity2);
					writer.newLine();
					writer.write(Medician3 +"     "+day3+"     "+Time3+"     "+quantity3);
					writer.newLine();
					writer.write(Medician4 +"     "+day4+"     "+Time4+"     "+quantity4);
					writer.newLine();
					writer.write(Medician5 +"     "+day5+"     "+Time5+"     "+quantity5);					
					writer.newLine();
					writer.write("Recommendation : " +recomo);					
					writer.newLine();
					writer.write("Next chekup : " +Checkups);					
					writer.newLine();
					Doctor_menu window = new Doctor_menu();
					window.frame.setVisible(true);
					frame.setVisible(false);
		        } catch (IOException ex) {
		            ex.printStackTrace(); // Handle the exception appropriately
		            JOptionPane.showMessageDialog(null, "Error writing to file", "File Error", JOptionPane.ERROR_MESSAGE);
		        
				patient_menu window = new patient_menu();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
			}else {
	            JOptionPane.showMessageDialog(null, "Input are not integer of DAY or QUANTITY ", "File Error", JOptionPane.ERROR_MESSAGE);
	        
			}}
		});
		button_1.setBounds(388, 499, 70, 22);
		frame.getContentPane().add(button_1);
		
		JLabel lblNewLabel = new JLabel("Prescriptions");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel.setBounds(173, 32, 139, 22);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel petientName = new JLabel("Patient Name");
		petientName.setFont(new Font("Tahoma", Font.BOLD, 13));
		petientName.setBounds(74, 72, 101, 14);
		frame.getContentPane().add(petientName);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(173, 70, 207, 20);
		frame.getContentPane().add(textField);
		
		medician1 = new JTextField();
		medician1.setColumns(10);
		medician1.setBounds(31, 133, 165, 20);
		frame.getContentPane().add(medician1);
		
		JLabel lblNewLabel_1 = new JLabel("Medicians");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1.setBounds(74, 112, 86, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Day");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_1_1.setBounds(210, 112, 86, 14);
		frame.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_2 = new JLabel("M");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2.setBounds(294, 112, 20, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("E");
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2_1.setBounds(320, 113, 20, 14);
		frame.getContentPane().add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_2 = new JLabel("N");
		lblNewLabel_2_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2_2.setBounds(346, 113, 20, 14);
		frame.getContentPane().add(lblNewLabel_2_2);
		
		Quantity1 = new JTextField();
		Quantity1.setColumns(10);
		Quantity1.setBounds(388, 133, 54, 20);
		frame.getContentPane().add(Quantity1);
		
		JLabel lblNewLabel_3 = new JLabel("Quantity");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_3.setBounds(388, 113, 63, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		medician2 = new JTextField();
		medician2.setColumns(10);
		medician2.setBounds(31, 159, 165, 20);
		frame.getContentPane().add(medician2);
		
		Quantity2 = new JTextField();
		Quantity2.setColumns(10);
		Quantity2.setBounds(388, 159, 54, 20);
		frame.getContentPane().add(Quantity2);
		
		medician3 = new JTextField();
		medician3.setColumns(10);
		medician3.setBounds(31, 185, 165, 20);
		frame.getContentPane().add(medician3);
		
		Quantity3 = new JTextField();
		Quantity3.setColumns(10);
		Quantity3.setBounds(388, 185, 54, 20);
		frame.getContentPane().add(Quantity3);
		
		medician4 = new JTextField();
		medician4.setColumns(10);
		medician4.setBounds(31, 211, 165, 20);
		frame.getContentPane().add(medician4);
		
		Quantity4 = new JTextField();
		Quantity4.setColumns(10);
		Quantity4.setBounds(388, 211, 54, 20);
		frame.getContentPane().add(Quantity4);
		
		medician5 = new JTextField();
		medician5.setColumns(10);
		medician5.setBounds(31, 237, 165, 20);
		frame.getContentPane().add(medician5);
		
		Quantity5 = new JTextField();
		Quantity5.setColumns(10);
		Quantity5.setBounds(388, 237, 54, 20);
		frame.getContentPane().add(Quantity5);
		
		JLabel lblNewLabel_3_1 = new JLabel("Recommendations");
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_3_1.setBounds(31, 262, 139, 14);
		frame.getContentPane().add(lblNewLabel_3_1);
		
		Day1 = new JTextField();
		Day1.setColumns(10);
		Day1.setBounds(232, 133, 44, 20);
		frame.getContentPane().add(Day1);
		
		time1 = new JTextField();
		time1.setColumns(10);
		time1.setBounds(296, 133, 70, 20);
		frame.getContentPane().add(time1);
		
		Day2 = new JTextField();
		Day2.setColumns(10);
		Day2.setBounds(232, 159, 44, 20);
		frame.getContentPane().add(Day2);
		
		time2 = new JTextField();
		time2.setColumns(10);
		time2.setBounds(296, 159, 70, 20);
		frame.getContentPane().add(time2);
		
		Day4 = new JTextField();
		Day4.setColumns(10);
		Day4.setBounds(232, 211, 44, 20);
		frame.getContentPane().add(Day4);
		
		Day3 = new JTextField();
		Day3.setColumns(10);
		Day3.setBounds(232, 185, 44, 20);
		frame.getContentPane().add(Day3);
		
		time3 = new JTextField();
		time3.setColumns(10);
		time3.setBounds(296, 185, 70, 20);
		frame.getContentPane().add(time3);
		
		time4 = new JTextField();
		time4.setColumns(10);
		time4.setBounds(296, 211, 70, 20);
		frame.getContentPane().add(time4);
		
		Day5 = new JTextField();
		Day5.setColumns(10);
		Day5.setBounds(232, 237, 44, 20);
		frame.getContentPane().add(Day5);
		
		time5 = new JTextField();
		time5.setColumns(10);
		time5.setBounds(296, 237, 70, 20);
		frame.getContentPane().add(time5);
		
		
		
		JLabel lblNewLabel_3_1_1 = new JLabel("Next Checkup");
		lblNewLabel_3_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_3_1_1.setBounds(31, 380, 139, 14);
		frame.getContentPane().add(lblNewLabel_3_1_1);
		
		recomme = new TextArea();
		recomme.setFont(new Font("Dialog", Font.PLAIN, 12));
		recomme.setBounds(31, 278, 411, 96);
		frame.getContentPane().add(recomme);
		
		logout = new Button("Log out");
		logout.setFont(new Font("Dialog", Font.BOLD, 12));
		logout.setBounds(399, 10, 70, 22);
		frame.getContentPane().add(logout);
	}
}
