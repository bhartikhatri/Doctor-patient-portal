package bharti;

import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;

public class Doctor_login {

	public JFrame frame;
	private JTextField txtUsername;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Doctor_login window = new Doctor_login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Doctor_login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	
	private void initialize() {
		
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("LOG IN");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 26));
		lblNewLabel.setBounds(160, 65, 113, 32);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Email");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(79, 127, 74, 20);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblNewLabel_2.setBounds(79, 158, 74, 23);
		frame.getContentPane().add(lblNewLabel_2);
		
		txtUsername = new JTextField();
		txtUsername.setBounds(160, 129, 161, 20);
		frame.getContentPane().add(txtUsername);
		txtUsername.setColumns(10);

		JButton btnNewButton = new JButton("Next");
		btnNewButton.addActionListener(new ActionListener() {
		    @SuppressWarnings("unlikely-arg-type")
		    public void actionPerformed(ActionEvent e) {
		    	String enteredUsername = txtUsername.getText();
                String enteredPassword = passwordField.getText();

                // Check credentials against patient_signup_data.txt
                if (checkCredentials(enteredUsername, enteredPassword)) {
                    // Allow access to the next page (patient_menu)
                	Doctor_menu window = new Doctor_menu();
					window.frame.setVisible(true);
					frame.setVisible(false);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                } else {
                    // Display an error message if credentials are incorrect
                    JOptionPane.showMessageDialog(null, "Invalid login credentials", "Login Error", JOptionPane.ERROR_MESSAGE);
                }
		    	
		    }
		});

		btnNewButton.setBounds(335, 227, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login window = new Login();
				window.frame.setVisible(true);
			}
		});
		btnNewButton_1.setBounds(10, 227, 89, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(160, 160, 161, 20);
		frame.getContentPane().add(passwordField);
	
	}
	private boolean checkCredentials(String enteredUsername, String enteredPassword) {
        // Specify the path to your patient_signup_data.txt file
        String filePath = "Doctor_login_data.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Split each line into username and password using a delimiter (e.g., comma)
                String[] parts = line.split(",");
                String usernameFromFile = parts[0].trim().substring("Username: ".length()).trim();
                String passwordFromFile = parts[1].trim().substring("Password: ".length()).trim();

                // Check if entered credentials match any entry in the file
                if (enteredUsername.equals(usernameFromFile) && enteredPassword.equals(passwordFromFile)) {
                    return true; // Credentials match
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "invalid email or password ", "Error", JOptionPane.ERROR_MESSAGE);
	       
            // Handle the exception appropriately (e.g., display an error message)
        }

        return false; // Credentials do not match or an error occurred
    }
}
