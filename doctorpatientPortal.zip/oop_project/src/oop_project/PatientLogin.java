package bharti;

import java.awt.EventQueue;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class PatientLogin {

	JFrame frame;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PatientLogin window = new PatientLogin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PatientLogin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("LOG IN");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 26));
		lblNewLabel.setBounds(170, 46, 102, 23);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(68, 107, 66, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_2.setBounds(68, 144, 66, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("Next");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                String enteredUsername = textField.getText();
                String enteredPassword = passwordField.getText();

                // Check credentials against patient_signup_data.txt
                if (checkCredentials(enteredUsername, enteredPassword)) {
                    // Allow access to the next page (patient_menu)
                    patient_menu window = new patient_menu();
                    window.frame.setVisible(true);
                    frame.setVisible(false);
                } else {
                    // Display an error message if credentials are incorrect
                    JOptionPane.showMessageDialog(null, "Invalid login credentials", "Login Error", JOptionPane.ERROR_MESSAGE);
                }
			}
		});
		btnNewButton.setBounds(245, 210, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Sign Up");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Patient_Signup window = new Patient_Signup();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		btnNewButton_1.setBounds(105, 210, 89, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		textField = new JTextField();
		textField.setBounds(152, 105, 131, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Don't have account ?");
		lblNewLabel_3.setBounds(36, 197, 131, 14);
		frame.getContentPane().add(lblNewLabel_3);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(151, 142, 132, 20);
		frame.getContentPane().add(passwordField);
	}
    private boolean checkCredentials(String enteredUsername, String enteredPassword) {
        // Specify the path to your patient_signup_data.txt file
        String filePath = "patient_signup_data.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Split each line into username and password using a delimiter (e.g., comma)
                String[] parts = line.split(",");
                String usernameFromFile = parts[0].trim().substring("Username: ".length()).trim();
                String passwordFromFile = parts[1].trim().substring("Password: ".length()).trim();

                // Check if entered credentials match any entry in the file
                if (enteredUsername.equals(usernameFromFile) && enteredPassword.equals(passwordFromFile)) {
                    return true; // Credentials match
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
            // Handle the exception appropriately (e.g., display an error message)
        }

        return false; // Credentials do not match or an error occurred
    }

}
