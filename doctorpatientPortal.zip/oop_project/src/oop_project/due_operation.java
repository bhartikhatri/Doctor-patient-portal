package bharti;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.TextArea;

public class due_operation {

	JFrame frame;
	private JTextField NAME;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					due_operation window = new due_operation();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public due_operation() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Due Operation");
		lblNewLabel.setFont(new Font("Tabarra Black", Font.BOLD, 26));
		lblNewLabel.setBounds(111, 37, 205, 33);
		frame.getContentPane().add(lblNewLabel);
		
		Button button_2 = new Button("Log out");
		button_2.setBounds(354, 10, 70, 22);
		frame.getContentPane().add(button_2);
		TextArea textArea = new TextArea();
		textArea.setBounds(52, 104, 325, 141);
		frame.getContentPane().add(textArea);
		
		Button button = new Button("< Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Doctor_menu window = new Doctor_menu();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		button.setBounds(10, 10, 70, 22);
		frame.getContentPane().add(button);
		
		Button button_1 = new Button("Show");
		button_1.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				String name=NAME.getText();
				if (name.equals("Mahesh")||name.equals("mahesh")||name.equals("Abdul aziz")||name.equals("abdul aziz")||name.equals("Bhageshwari")||name.equals("bhageshwari")) {
				try (BufferedReader reader = new BufferedReader(new FileReader("operations.txt"))) {
		            StringBuilder content = new StringBuilder();
		            String line;

		            // Read lines from the file and append to the content StringBuilder
		            while ((line = reader.readLine()) != null) {
		                content.append(line).append("\n");
		            }

		            // Set the content to the text area
		            textArea.setText(content.toString());
		        } catch (IOException ex) {
		            // Handle file not found or other IO exceptions
		            ex.printStackTrace();
		            JOptionPane.showMessageDialog(null, "File not found or error reading file", "Error", JOptionPane.ERROR_MESSAGE);
		        }
			  }else {
				  JOptionPane.showMessageDialog(null, "Entered doctor name is invalid", "Error", JOptionPane.ERROR_MESSAGE);
			        
			  }
			}
		});
		button_1.setBounds(320, 76, 57, 22);
		frame.getContentPane().add(button_1);
		
		NAME = new JTextField();
		NAME.setColumns(10);
		NAME.setBounds(144, 78, 174, 20);
		frame.getContentPane().add(NAME);
		
		JLabel lblNewLabel_1 = new JLabel("Doctor Name :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_1.setBounds(55, 76, 85, 22);
		frame.getContentPane().add(lblNewLabel_1);
		
		
	}
}
