package bharti;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Button;
import java.awt.List;
import java.awt.TextArea;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class Doctor_Due_checkup {

	JFrame frame;
	private JTextField NAME;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Doctor_Due_checkup window = new Doctor_Due_checkup();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Doctor_Due_checkup() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Due Checkup");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 26));
		lblNewLabel.setBounds(126, 25, 183, 49);
		frame.getContentPane().add(lblNewLabel);
		
		Button button = new Button("< Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Doctor_menu window = new Doctor_menu();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		button.setBounds(10, 10, 70, 22);
		frame.getContentPane().add(button);
		
		Button button_1 = new Button("Log out");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login window = new Login();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		button_1.setBounds(354, 10, 70, 22);
		frame.getContentPane().add(button_1);
		
		TextArea textArea = new TextArea();
		textArea.setBounds(62, 105, 321, 135);
		frame.getContentPane().add(textArea);
		
		Button button_2 = new Button("Show");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name=NAME.getText();
				if (name.equals("Mahesh")||name.equals("mahesh")||name.equals("Abdul aziz")||name.equals("abdul aziz")||name.equals("Bhageshwari")||name.equals("bhageshwari")) {
					
				try (BufferedReader reader = new BufferedReader(new FileReader(name+".txt"))) {
		            StringBuilder content = new StringBuilder();
		            String line;

		            // Read lines from the file and append to the content StringBuilder
		            while ((line = reader.readLine()) != null) {
		                content.append(line).append("\n");
		            }

		            // Set the content to the text area
		            textArea.setText(content.toString());
		        } catch (IOException ex) {
		            // Handle file not found or other IO exceptions
		            ex.printStackTrace();
		            JOptionPane.showMessageDialog(null, "File not found or error reading file", "Error", JOptionPane.ERROR_MESSAGE);
		        }
			}else {
				JOptionPane.showMessageDialog(null, "Entered doctor name is invalid", "Error", JOptionPane.ERROR_MESSAGE);
		        
			}
			}
		});
		button_2.setBounds(330, 77, 53, 22);
		frame.getContentPane().add(button_2);
		
		JLabel lblNewLabel_1 = new JLabel("Doctor Name :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblNewLabel_1.setBounds(61, 77, 85, 22);
		frame.getContentPane().add(lblNewLabel_1);
		
		NAME = new JTextField();
		NAME.setBounds(150, 79, 174, 20);
		frame.getContentPane().add(NAME);
		NAME.setColumns(10);
	}
}
