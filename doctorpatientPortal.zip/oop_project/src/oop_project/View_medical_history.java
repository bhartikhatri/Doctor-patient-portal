package bharti;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

import java.awt.Font;
import java.awt.Button;
import java.awt.TextArea;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class View_medical_history {

	JFrame frame;
	private JTextField textField;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					View_medical_history window = new View_medical_history();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public View_medical_history() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblViewPrescription = new JLabel("Medical History");
		lblViewPrescription.setFont(new Font("Tahoma", Font.BOLD, 26));
		lblViewPrescription.setBounds(100, 26, 236, 49);
		frame.getContentPane().add(lblViewPrescription);
		
		Button button = new Button("< Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				patient_menu window = new patient_menu();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		TextArea textArea = new TextArea();
		textArea.setBounds(35, 109, 363, 142);
		frame.getContentPane().add(textArea);
		button.setBounds(10, 10, 70, 22);
		frame.getContentPane().add(button);
		
		Button button_1 = new Button("Search");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
                String enteredData = textField.getText().trim();

                // Construct the filename based on the entered data
                String fileName = "patient_"+enteredData + ".txt";

                // Read data from the file and display it in the text area
                try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
                    StringBuilder content = new StringBuilder();
                    String line;

                    // Read lines from the file and append to the content StringBuilder
                    while ((line = reader.readLine()) != null) {
                        content.append(line).append("\n");
                    }

                    // Set the content to the text area
                    textArea.setText(content.toString());
                } catch (IOException ex) {
                    // Handle file not found or other IO exceptions
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "File not found or error reading file", "Error", JOptionPane.ERROR_MESSAGE);
                }
			}
		});
		button_1.setBounds(309, 73, 57, 22);
		frame.getContentPane().add(button_1);
		
		JLabel lblNewLabel = new JLabel("Name :");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(62, 73, 57, 14);
		frame.getContentPane().add(lblNewLabel);
		
		textField = new JTextField();
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setColumns(10);
		textField.setBounds(122, 73, 181, 20);
		frame.getContentPane().add(textField);
		
		Button button_2 = new Button("Log out");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login window = new Login();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		button_2.setBounds(354, 10, 70, 22);
		frame.getContentPane().add(button_2);
		
		
	}
    
}
