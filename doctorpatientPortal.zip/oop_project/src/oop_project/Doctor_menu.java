package bharti;

import java.awt.Button;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Doctor_menu {

	JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Doctor_menu window = new Doctor_menu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Doctor_menu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("List of Patients");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				List_of_patient window = new List_of_patient();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setBounds(116, 67, 195, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Due Checkups");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Doctor_Due_checkup window = new Doctor_Due_checkup();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_1.setBounds(116, 101, 195, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_3 = new JButton("Give Prescription");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Give_prescription window = new Give_prescription();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_3.setBounds(116, 135, 195, 23);
		frame.getContentPane().add(btnNewButton_3);
		
		JLabel lblNewLabel = new JLabel("MENU");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 26));
		lblNewLabel.setBounds(169, 14, 84, 23);
		frame.getContentPane().add(lblNewLabel);
		
		Button button = new Button("< Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login window = new Login();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		button.setBounds(10, 10, 70, 22);
		frame.getContentPane().add(button);
		
		Button button_1 = new Button("Log out");
		button_1.setFont(new Font("Dialog", Font.BOLD, 13));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login window = new Login();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		button_1.setBounds(354, 229, 70, 22);
		frame.getContentPane().add(button_1);
		
		JButton btnViewPatientHistory = new JButton("View Patient History");
		btnViewPatientHistory.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Patient_medical_history window = new Patient_medical_history();
				window.frame.setVisible(true);
			}
		});
		btnViewPatientHistory.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnViewPatientHistory.setBounds(116, 169, 195, 23);
		frame.getContentPane().add(btnViewPatientHistory);
		
		JButton btnViewPatientFeedbak = new JButton("View Patient feedbak");
		btnViewPatientFeedbak.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				View_patients_feedback window = new View_patients_feedback();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		btnViewPatientFeedbak.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnViewPatientFeedbak.setBounds(116, 203, 195, 23);
		frame.getContentPane().add(btnViewPatientFeedbak);
	}
}
